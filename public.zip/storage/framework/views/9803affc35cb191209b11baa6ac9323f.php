

<table id="staff-datatable" class="table table-striped table-bordered w-100 mb-0">
    <thead>
        <tr>
            <th>#</th>
            <th>Name</th>
            <th>Position</th>
            <th>Status</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        
    </tbody>
</table>
<?php /**PATH D:\Laravel\Skolabs\resources\views/staff/components/table-staff.blade.php ENDPATH**/ ?>