
<div class="modal fade" id="classModal" tabindex="-1" aria-labelledby="classModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="classModalLabel">Add New Class</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="classForm" novalidate>
                    <?php echo csrf_field(); ?>
                    
                    <input type="hidden" id="classId" name="id">
                    <input type="hidden" id="generatedClassName" name="name">

                    <div class="row">
                        
                        <div class="col-md-12 mb-3">
                            <label for="gradeLevel" class="form-label">Grade</label>
                            <select class="form-select" id="gradeLevel" name="grade_level" required>
                                <option value="">Select Grade</option>
                                
                            </select>
                            <div class="invalid-feedback">Please select a grade.</div>
                        </div>

                        
                        <div class="col-md-12 mb-3">
                            <label for="educationalLevelId" class="form-label">Educational Level</label>
                            <select class="form-select" id="educationalLevelId" name="educational_level_id" required>
                                <option value="">Select Level</option>
                                
                            </select>
                            <div class="invalid-feedback">Please select an educational level.</div>
                        </div>

                        
                        <div class="col-md-12 mb-3">
                            <label for="majorId" class="form-label">Major</label>
                            <select class="form-select" id="majorId" name="major_id" required disabled>
                                <option value="">Select Level First</option>
                                
                            </select>
                            <div class="invalid-feedback">Please select a major.</div>
                        </div>

                        
                        <div class="col-md-12 mb-3">
                            <label for="teacherId" class="form-label">Homeroom Teacher</label>
                            <select class="form-select" id="teacherId" name="teacher_id" required>
                                <option value="">Select a Teacher</option>
                                
                            </select>
                            <div class="invalid-feedback">Please select a homeroom teacher.</div>
                        </div>
                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary" id="saveClassBtn">Save changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\Laravel\Skolabs\resources\views/class/components/modal-class.blade.php ENDPATH**/ ?>