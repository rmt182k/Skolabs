

<!-- Brand Logo Dark -->
<a href="index.html" class="logo logo-dark">
    <span class="logo-lg">
        <img src="assets/images/logo-dark.png" alt="dark logo">
    </span>
    <span class="logo-sm">
        <img src="assets/images/logo-dark-sm.png" alt="small logo">
    </span>
</a>
<?php /**PATH D:\Laravel\Skolabs\resources\views/layouts/components/sidebar-brand_logo.blade.php ENDPATH**/ ?>