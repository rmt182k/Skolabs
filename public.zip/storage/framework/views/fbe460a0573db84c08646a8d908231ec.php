<div class="tab-pane fade" id="report" role="tabpanel" aria-labelledby="report-tab">
    <div class="card">
        <div class="card-body">
            <h4 class="header-title mb-3">Financial Report</h4>
            <p>📊 Laporan keuangan bisa ditaruh di sini.</p>
        </div>
    </div>
</div>
<?php /**PATH D:\Laravel\Skolabs\resources\views/dashboard/tabs/report.blade.php ENDPATH**/ ?>