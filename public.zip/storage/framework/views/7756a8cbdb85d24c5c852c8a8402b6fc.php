 
<?php $__env->startSection('title', 'Mengerjakan Tugas'); ?>

<?php $__env->startPush('styles'); ?>
    
    <style>
        .question-card {
            border: 1px solid #ddd;
            border-left: 5px solid #0d6efd;
            border-radius: 5px;
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4">
    
    <div id="loading-spinner" class="text-center py-5">
        <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status"></div>
        <p class="mt-3">Memuat tugas...</p>
    </div>

    
    <div id="assignment-content" class="d-none">
        
        <div class="card shadow-sm mb-4">
            <div class="card-body">
                <h1 id="assignment-title" class="h3 fw-bold"></h1>
                <div class="text-muted mb-3">
                    <span id="assignment-teacher" class="me-3"></span> |
                    <span id="assignment-subject" class="mx-3"></span> |
                    <span id="assignment-due-date" class="ms-3 text-danger fw-semibold"></span>
                </div>
                <hr>
                <p id="assignment-description"></p>
            </div>
        </div>

        
        <form id="submissionForm">
            
            <div id="question-container">
                
            </div>

            
            <div class="mt-4 text-end">
                <button type="submit" class="btn btn-success btn-lg">
                    <i class="fas fa-paper-plane me-2"></i> Kumpulkan Jawaban
                </button>
            </div>
        </form>
    </div>
</div>






<template id="short-answer-question-template">
    <div class="card shadow-sm mb-3 question-card">
        <div class="card-header bg-light d-flex justify-content-between">
            <h6 class="question-number fw-bold mb-0"></h6>
            <span class="question-score badge bg-primary"></span>
        </div>
        <div class="card-body">
            <div class="question-text mb-3"></div>
            <div class="answer-area">
                <label class="form-label fw-semibold">Jawaban Anda:</label>
                <input type="text" class="form-control student-answer" name="answer" placeholder="Ketik jawaban singkat Anda..." required>
            </div>
        </div>
    </div>
</template>


<template id="essay-question-template">
    <div class="card shadow-sm mb-3 question-card">
        <div class="card-header bg-light d-flex justify-content-between">
            <h6 class="question-number fw-bold mb-0"></h6>
            <span class="question-score badge bg-primary"></span>
        </div>
        <div class="card-body">
            <div class="question-text mb-3"></div>
            <div class="answer-area">
                <label class="form-label fw-semibold">Jawaban Anda:</label>
                <textarea class="form-control student-answer" name="answer" rows="5" placeholder="Ketik jawaban esai Anda..." required></textarea>
            </div>
        </div>
    </div>
</template>


<template id="multiple-choice-question-template">
    <div class="card shadow-sm mb-3 question-card">
        <div class="card-header bg-light d-flex justify-content-between">
            <h6 class="question-number fw-bold mb-0"></h6>
            <span class="question-score badge bg-primary"></span>
        </div>
        <div class="card-body">
            <div class="question-text mb-3"></div>
            <div class="answer-area">
                <label class="form-label fw-bold">Pilih jawaban yang benar:</label>
                <div class="options-container">
                    
                </div>
            </div>
        </div>
    </div>
</template>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script> 
<script src="<?php echo e(asset('assets/js/app/student-assigment/studentAssignmentForm.js')); ?>" defer></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.auth', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Laravel\Skolabs\resources\views/student-assignment/partials/form.blade.php ENDPATH**/ ?>