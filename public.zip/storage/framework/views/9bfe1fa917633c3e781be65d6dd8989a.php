<table id="admins-datatable" class="table table-striped table-bordered w-100 mb-0">
    <thead>
        <tr>
            <th>#</th>
            <th>Name</th>
            <th>Email</th>
            <th>Job Title</th>
            <th>Status</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
    </tbody>
</table>
<?php /**PATH D:\Laravel\Skolabs\resources\views/admin/components/table-admin.blade.php ENDPATH**/ ?>