<?php $__env->startSection('title', 'Student Management'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        
        <?php echo $__env->make('layouts.components.breadcrumb', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <div class="row">
            <div class="col-12">
                <div class="card">
                     <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="card-title mb-0">Student List</h5>
                        <button id="studentAddBtn" class="btn btn-primary">
                            <i class="fas fa-plus me-1"></i> Add New Student
                        </button>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <?php echo $__env->make('student.components.table-student', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('student.components.modal-student', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('assets/js/app/student/student.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.auth', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Laravel\Skolabs\resources\views/student/index.blade.php ENDPATH**/ ?>