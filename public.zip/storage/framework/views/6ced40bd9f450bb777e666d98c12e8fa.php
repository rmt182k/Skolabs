<table class="table table-bordered table-striped" id="assignStudentsTable">
    <thead>
        <tr>
            <th>Class Name</th>
            <th>Student Name</th>
            <th>Major</th>
            <th>Homeroom Teacher</th>
            <th>Assigned At</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        
    </tbody>
</table>
<?php /**PATH D:\Laravel\Skolabs\resources\views/class-student/components/table-class_student.blade.php ENDPATH**/ ?>