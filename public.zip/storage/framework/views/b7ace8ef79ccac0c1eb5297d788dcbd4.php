<?php $__env->startSection('title', 'Teacher Management'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        
        <?php echo $__env->make('layouts.components.breadcrumb', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <h4 class="header-title">Teachers Table</h4>
                        <p class="text-muted font-14 mb-4">
                            List of teachers registered in the system. You can add, edit, or delete teacher data.
                        </p>

                        <div class="table-responsive">
                            <div class="d-flex justify-content-end mb-3">
                                <button type="button" class="btn btn-primary" id="teacherAddBtn">
                                    <i class="fas fa-plus me-1"></i> Add New Teacher
                                </button>
                            </div>
                            <?php echo $__env->make('teacher.components.table-teacher', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <?php echo $__env->make('teacher.components.modal-teacher', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    
    <script src="<?php echo e(asset('assets/js/app/teacher/teacher.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.auth', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Laravel\Skolabs\resources\views/teacher/index.blade.php ENDPATH**/ ?>