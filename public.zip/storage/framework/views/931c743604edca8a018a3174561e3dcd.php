<table id="all-submissions-datatable" class="table table-bordered dt-responsive nowrap" style="width:100%">
    <thead class="table-light">
        <tr>
            <th>ID</th>
            <th>Assignment Title</th>
            <th>Student Name</th>
            <th>Submitted At</th>
            <th>Status</th>
            <th>Grade</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
    </tbody>
</table>
<?php /**PATH D:\Laravel\Skolabs\resources\views/assignment-submission/components/table-submission.blade.php ENDPATH**/ ?>