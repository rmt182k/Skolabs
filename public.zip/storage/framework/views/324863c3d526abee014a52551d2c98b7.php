<div class="tab-pane fade" id="analytics" role="tabpanel" aria-labelledby="analytics-tab">
    <div class="card">
        <div class="card-body">
            <h4 class="header-title mb-3">Patient Analytics</h4>
            <p>👩‍⚕️ Grafik atau data analitik pasien bisa ditaruh di sini.</p>
        </div>
    </div>
</div>
<?php /**PATH D:\Laravel\Skolabs\resources\views/dashboard/tabs/analytics.blade.php ENDPATH**/ ?>