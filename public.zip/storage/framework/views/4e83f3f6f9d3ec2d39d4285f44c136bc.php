<?php $__env->startSection('title', 'Educational Levels'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <?php echo $__env->make('layouts.components.breadcrumb', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <h4 class="header-title">Educational Levels Table</h4>
                        <p class="text-muted font-14 mb-4">
                            Manage the various educational levels within the system.
                        </p>

                        
                        <div class="table-responsive">
                            <div class="d-flex justify-content-end mb-3">
                                <button type="button" class="btn btn-primary" data-bs-toggle="modal"
                                    data-bs-target="#educationalLevelModal" id="addEducationalLevelBtn">Add</button>
                            </div>
                            <?php echo $__env->make('educational-level.components.table-educational_level', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        </div>
                    </div> <!-- end card body-->
                </div> <!-- end card -->
            </div><!-- end col-->
        </div> <!-- end row-->

        <?php echo $__env->make('educational-level.components.modal-educational_level', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('assets/js/app/educational-level/educational-level.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/app/utils/tableConfig.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.auth', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Laravel\Skolabs\resources\views/educational-level/index.blade.php ENDPATH**/ ?>