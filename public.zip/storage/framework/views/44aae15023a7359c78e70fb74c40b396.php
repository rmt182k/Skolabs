<table id="majorTable" class="table table-bordered table-striped">
    <thead>
        <tr>
            <th>#</th>
            <th>Level</th>
            <th>Name</th>
            <th>Description</th>
            <th>Created At</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
    </tbody>
</table>
<?php /**PATH D:\Laravel\Skolabs\resources\views/major/components/table-major.blade.php ENDPATH**/ ?>