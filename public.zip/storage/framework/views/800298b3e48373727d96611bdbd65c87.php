<div class="tab-pane fade show active" id="overview" role="tabpanel" aria-labelledby="overview-tab">
    <div class="row">
        <div class="col-md-6 col-xl-3">
            <div class="card">
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col-6">
                            <h5 class="text-muted fw-normal mt-0" title="Total Patients">Total Patients</h5>
                            <h3 class="mt-3 mb-3">1,234</h3>
                        </div>
                        <div class="col-6 text-end">
                            <div class="avatar-sm d-inline-block">
                                <span class="avatar-title bg-info-lighten rounded">
                                    <i class="mdi mdi-account-group text-info font-24"></i>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-6 col-xl-3">
            <div class="card">
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col-6">
                            <h5 class="text-muted fw-normal mt-0" title="Daily Revenue">Daily Revenue</h5>
                            <h3 class="mt-3 mb-3">$15,500</h3>
                        </div>
                        <div class="col-6 text-end">
                            <div class="avatar-sm d-inline-block">
                                <span class="avatar-title bg-success-lighten rounded">
                                    <i class="mdi mdi-cash-multiple text-success font-24"></i>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <h4 class="header-title mb-3">Today's Appointments</h4>
                    <div class="table-responsive">
                        <table class="table table-centered table-nowrap mb-0">
                            <thead>
                                <tr>
                                    <th>Patient Name</th>
                                    <th>Time</th>
                                    <th>Status</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>John Doe</td>
                                    <td>09:00 AM</td>
                                    <td><span class="badge bg-success">Confirmed</span></td>
                                </tr>
                                <tr>
                                    <td>Jane Smith</td>
                                    <td>10:30 AM</td>
                                    <td><span class="badge bg-warning">Pending</span></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\Laravel\Skolabs\resources\views/dashboard/tabs/overview.blade.php ENDPATH**/ ?>