<table id="majorTable" class="table table-bordered table-striped">
    <thead>
        <tr>
            <th>#</th>
            <th>Level</th>
            <th>Name</th>
            <th>Description</th>
            <th>Created At</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
    </tbody>
</table>
