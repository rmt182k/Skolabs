{{-- File: resources/views/student/components/table-student.blade.php --}}

<table id="studentTable" class="table table-striped table-bordered w-100 mb-0">
    <thead>
        <tr>
            <th>#</th>
            <th>NISN</th>
            <th>Name</th>
            <th>Grade</th>
            <th>Status</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
    </tbody>
</table>
