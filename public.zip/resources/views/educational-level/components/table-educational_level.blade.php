<table class="table table-bordered table-striped" id="educationalLevelsTable">
    <thead>
        <tr>
            <th>Name</th>
            <th>Duration (Years)</th>
            <th>Description</th>
            <th>Created At</th>
            <th>Updated At</th>
            <th>Action</th>
        </tr>
    </thead>
    <tbody>
        {{-- Data will be populated here by JavaScript --}}
    </tbody>
</table>
