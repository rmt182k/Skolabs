<li class="dropdown">
    <a class="nav-link dropdown-toggle arrow-none" data-bs-toggle="dropdown" href="#" role="button"
        aria-haspopup="false" aria-expanded="false">
        <img src="assets/images/flags/us.jpg" alt="user-image" class="me-0 me-sm-1" height="12">
        <span class="align-middle d-none d-lg-inline-block">English</span> <i
            class="mdi mdi-chevron-down d-none d-sm-inline-block align-middle"></i>
    </a>
    <div class="dropdown-menu dropdown-menu-end dropdown-menu-animated">

        <!-- item-->
        <a href="javascript:void(0);" class="dropdown-item">
            <img src="assets/images/flags/germany.jpg" alt="user-image" class="me-1" height="12">
            <span class="align-middle">German</span>
        </a>

        <!-- item-->
        <a href="javascript:void(0);" class="dropdown-item">
            <img src="assets/images/flags/italy.jpg" alt="user-image" class="me-1" height="12">
            <span class="align-middle">Italian</span>
        </a>

        <!-- item-->
        <a href="javascript:void(0);" class="dropdown-item">
            <img src="assets/images/flags/spain.jpg" alt="user-image" class="me-1" height="12">
            <span class="align-middle">Spanish</span>
        </a>

        <!-- item-->
        <a href="javascript:void(0);" class="dropdown-item">
            <img src="assets/images/flags/russia.jpg" alt="user-image" class="me-1" height="12">
            <span class="align-middle">Russian</span>
        </a>

    </div>
</li>
