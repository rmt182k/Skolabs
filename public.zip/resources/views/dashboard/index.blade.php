@extends('layouts.auth')

@section('title', 'Skolabs Dashboard')

@section('content')
    <div class="container-fluid">
        @include('layouts.components.breadcrumb')
    </div>
@endsection

