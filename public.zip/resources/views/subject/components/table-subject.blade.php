<table id="subjectsTable" class="table table-bordered table-striped" style="width:100%">
    <thead>
        <tr>
            <th>Name</th>
            <th>Code</th>
            <th>Teachers</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody></tbody>
</table>
