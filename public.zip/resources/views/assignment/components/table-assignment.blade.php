<table id="assignment-datatable" class="table table-bordered dt-responsive nowrap" style="width:100%">
    <thead class="table-light">
        <tr>
            <th>ID</th>
            <th>Title</th>
            <th>Subject</th>
            <th>Class</th>
            <th>Start Date</th>
            <th>Due Date</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
    </tbody>
</table>

