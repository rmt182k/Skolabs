<table id="classesTable" class="table table-bordered table-striped dt-responsive nowrap" style="width:100%">
    <thead>
        <tr>
            <th>Class Name</th>
            <th>Grade</th>
            <th>Level</th>
            <th>Major</th>
            <th>Homeroom Teacher</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
    </tbody>
</table>
