@extends('layouts.auth')

@section('title', 'New Module')

@section('content')
    <div class="container-fluid">
        @include('layouts.components.breadcrumb')
    </div>
@endsection
@push('styles')
@endpush
@push('scripts')
@endpush
