<table id="materials-datatable" class="table table-bordered dt-responsive nowrap" style="width:100%">
    <thead class="table-light">
        <tr>
            <th>ID</th>
            <th>Title</th>
            <th>Subject</th>
            <th>Class</th>
            <th>Uploader</th>
            <th>File Type</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
    </tbody>
</table>
