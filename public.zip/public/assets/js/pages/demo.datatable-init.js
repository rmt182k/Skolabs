new DataTable("#basic-datatable", {
    language: {
        paginate: {
            first: '<i class="ri-arrow-left-double-line align-middle"></i>',
            previous: '<i class="ri-arrow-left-s-line align-middle"></i>',
            next: '<i class="ri-arrow-right-s-line align-middle"></i>',
            last: '<i class="ri-arrow-right-double-line align-middle"></i>'
        }
    }
}), document.addEventListener("DOMContentLoaded", () => {
    var e = document.querySelector("#datatable-buttons");
    e && new DataTable(e, {
        dom: "<'d-md-flex justify-content-between align-items-center my-2'Bf>rt<'d-md-flex justify-content-between align-items-center mt-2'ip>",
        responsive: !0,
        buttons: [{
            extend: "copy",
            className: "btn btn-sm btn-secondary"
        }, {
            extend: "csv",
            className: "btn btn-sm btn-secondary active"
        }, {
            extend: "excel",
            className: "btn btn-sm btn-secondary"
        }, {
            extend: "print",
            className: "btn btn-sm btn-secondary active"
        }, {
            extend: "pdf",
            className: "btn btn-sm btn-secondary"
        }],
        language: {
            paginate: {
                first: '<i class="ri-arrow-left-double-line align-middle"></i>',
                previous: '<i class="ri-arrow-left-s-line align-middle"></i>',
                next: '<i class="ri-arrow-right-s-line align-middle"></i>',
                last: '<i class="ri-arrow-right-double-line align-middle"></i>'
            }
        }
    })
}), document.addEventListener("DOMContentLoaded", () => {
    var e = document.querySelector("#selection-datatable");
    e && new DataTable(e, {
        pageLength: 7,
        lengthMenu: [7, 10, 25, 50, -1],
        select: "multi",
        language: {
            paginate: {
                first: '<i class="ri-arrow-left-double-line align-middle"></i>',
                previous: '<i class="ri-arrow-left-s-line align-middle"></i>',
                next: '<i class="ri-arrow-right-s-line align-middle"></i>',
                last: '<i class="ri-arrow-right-double-line align-middle"></i>'
            },
            lengthMenu: "_MENU_ Items per page",
            info: 'Showing <span class="fw-semibold">_START_</span> to <span class="fw-semibold">_END_</span> of <span class="fw-semibold">_TOTAL_</span> Items'
        }
    })
}), document.addEventListener("DOMContentLoaded", function() {
    var e = document.getElementById("scroll-datatable");
    e && (new DataTable(e, {
        paging: !1,
        scrollCollapse: !0,
        scrollY: "320px"
    }), new DataTable("#horizontal-scroll", {
        scrollX: !0,
        language: {
            paginate: {
                first: '<i class="ri-arrow-left-double-line align-middle"></i>',
                previous: '<i class="ri-arrow-left-s-line align-middle"></i>',
                next: '<i class="ri-arrow-right-s-line align-middle"></i>',
                last: '<i class="ri-arrow-right-double-line align-middle"></i>'
            },
            lengthMenu: "_MENU_ Items per page",
            info: 'Showing <span class="fw-semibold">_START_</span> to <span class="fw-semibold">_END_</span> of <span class="fw-semibold">_TOTAL_</span> Items'
        }
    }))
}), new DataTable("#complex-header-datatable", {
    language: {
        paginate: {
            first: '<i class="ri-arrow-left-double-line align-middle"></i>',
            previous: '<i class="ri-arrow-left-s-line align-middle"></i>',
            next: '<i class="ri-arrow-right-s-line align-middle"></i>',
            last: '<i class="ri-arrow-right-double-line align-middle"></i>'
        }
    }
}), document.addEventListener("DOMContentLoaded", () => {
    var e = document.getElementById("fixed-header-datatable");
    e && new DataTable(e, {
        fixedHeader: {
            header: !0,
            headerOffset: 70
        },
        pageLength: 15,
        language: {
            paginate: {
                first: '<i class="ri-arrow-left-double-line align-middle"></i>',
                previous: '<i class="ri-arrow-left-s-line align-middle"></i>',
                next: '<i class="ri-arrow-right-s-line align-middle"></i>',
                last: '<i class="ri-arrow-right-double-line align-middle"></i>'
            }
        }
    })
});
